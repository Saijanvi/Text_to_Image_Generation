import numpy as np
from PIL import Image
import pywt

def embed_message_in_image(cover_image_path, message_length, message):
    cover_image = Image.open(cover_image_path).convert('L')  # Convert to grayscale
    width, height = cover_image.size

    stego_image = np.array(cover_image)

    # Convert the message to binary
    binary_message = ''.join(format(ord(char), '08b') for char in message)

    # Ensure the message can fit into the stego image
    if len(binary_message) > width * height * 3:
        raise ValueError("Message is too large for the cover image")

    # Haar wavelet transform on the cover image
    coeffs = pywt.dwt2(stego_image, 'haar')
    LL, (LH, HL, HH) = coeffs

    # Embed the binary message in the LL (approximation) subband
    reshaped_message = [int(bit) for bit in binary_message[:len(LL.flat)]]

    # Convert the LL coefficients to uint8
    LL = np.round(LL).astype(np.uint8)

    LL_flat = LL.flat
    for j in range(len(reshaped_message)):
        if reshaped_message[j] == 1:
            LL_flat[j] |= 1
        else:
            LL_flat[j] &= np.uint8(254)

    # Inverse Haar wavelet transform
    coeffs = LL, (LH, HL, HH)
    stego_image = pywt.idwt2(coeffs, 'haar')

    stego_image = np.round(stego_image).astype(np.uint8)
    stego_image = Image.fromarray(stego_image)
    stego_image.save("cat_corr.jpg")

    # Calculate Correlation
    correlation = calculate_correlation(cover_image, stego_image)
    
    return message_length, correlation

def calculate_correlation(image1, image2):
    arr1 = np.array(image1)
    arr2 = np.array(image2)
    correlation = np.corrcoef(arr1.ravel(), arr2.ravel())[0, 1]
    return correlation

# Test the function for different message lengths
cover_image_path = "cat.jpg"
messages = {
    44: "The quick brown fox jumps over the lazy dog.",
    123: "Steganography is the practice of concealing a file, message, image, or video within another file, message, image, or video.",
    149: "In cryptography, steganography is often used to hide secret messages or information within an innocuous cover medium, such as an image or audio file.",
    164: "The art of steganography dates back to ancient times when people would hide secret messages by tattooing them on messengers' bodies or encoding them in wax tablets.",
    209: "Today, steganography finds applications in digital watermarking, copyright protection, covert communication, and data hiding in multimedia files, among other areas of computer science and information security."
}

for message_length, message in messages.items():
    message_length, correlation = embed_message_in_image(cover_image_path, message_length, message)
    print(f"Message Length: {message_length}, Correlation: {correlation}")