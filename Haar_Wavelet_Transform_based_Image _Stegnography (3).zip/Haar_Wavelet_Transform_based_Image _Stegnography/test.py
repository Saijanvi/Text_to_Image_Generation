import numpy as np
from PIL import Image
import pywt
import matplotlib.pyplot as plt

def extract_message_from_image(stego_image_path):
    stego_image = Image.open(stego_image_path).convert('L')  # Convert to grayscale
    stego_array = np.array(stego_image)

    # Show original stego image
    plt.figure(figsize=(5, 5))
    plt.imshow(stego_array, cmap='gray')
    plt.title('Original Stego Image')
    plt.axis('off')
    plt.show()

    # Haar wavelet transform on the stego image
    coeffs = pywt.dwt2(stego_array, 'haar')
    LL, _ = coeffs

    # Show LL coefficients image
    plt.figure(figsize=(5, 5))
    plt.imshow(LL, cmap='gray')
    plt.title('LL Coefficients Image')
    plt.axis('off')
    plt.show()

    # Flatten LL coefficients and convert to binary
    flattened_LL = LL.flatten().astype(np.uint8)
    binary_message = ''.join(['{0:08b}'.format(pixel) for pixel in flattened_LL])

    # Ensure the length of binary_message is a multiple of 8
    binary_message = binary_message[:-(len(binary_message) % 8)]

    # Convert binary message to characters
    message = ''
    for i in range(0, len(binary_message), 8):
        byte = binary_message[i:i+8]
        char = chr(int(byte, 2))
        if char == '\0':
            # Break the loop if a null character is encountered
            break
        message += char

    return message

# Example usage for message extraction
stego_image_path = "cat_stego_image.png"
extracted_message = extract_message_from_image(stego_image_path)
print("Extracted Message:", extracted_message)

