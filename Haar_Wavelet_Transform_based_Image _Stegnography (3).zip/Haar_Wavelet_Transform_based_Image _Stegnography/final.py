import numpy as np
from PIL import Image
import pywt

def psnr(original_image, compressed_image):
    mse = np.mean((original_image - compressed_image) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    return 20 * np.log10(max_pixel / np.sqrt(mse))

def embed_message_in_image(cover_image_path, message):
    cover_image = Image.open(cover_image_path).convert('L')  # Convert to grayscale
    width, height = cover_image.size

    stego_image = np.array(cover_image)

    # Convert the message to binary
    binary_message = ''.join(format(ord(char), '08b') for char in message)

    # Ensure the message can fit into the stego image
    if len(binary_message) > width * height:
        raise ValueError("Message is too large for the cover image")

    # Haar wavelet transform on the cover image
    coeffs = pywt.dwt2(stego_image, 'haar')
    LL, (LH, HL, HH) = coeffs

    # Embed the binary message in the LL (approximation) subband
    reshaped_message = [int(bit) for bit in binary_message]

    # Adjust the scaling factor for quantization
    scale_factor = 2  # You can adjust this value as needed

    # Quantize LL coefficients
    LL_quantized = np.round(LL / scale_factor).astype(np.uint8)

    # Embed message into LL subband
    reshaped_message_index = 0
    for i in range(LL_quantized.shape[0]):
        for j in range(LL_quantized.shape[1]):
            if reshaped_message_index < len(reshaped_message):
                if reshaped_message[reshaped_message_index] == 1:
                    LL_quantized[i][j] |= 1
                else:
                    LL_quantized[i][j] &= np.uint8(254)
                reshaped_message_index += 1

    # Inverse Haar wavelet transform
    coeffs = LL_quantized * scale_factor, (LH, HL, HH)
    stego_image = pywt.idwt2(coeffs, 'haar')

    stego_image = np.round(stego_image).astype(np.uint8)
    stego_image = Image.fromarray(stego_image)
    stego_image.save("cat_stego.jpg")

    # Calculate PSNR
    original_image = np.array(cover_image)
    compressed_image = np.array(stego_image)
    psnr_val = psnr(original_image, compressed_image)
    return psnr_val

cover_image_path = "C:/Users/hp/Desktop/mini_sem6/Haar_Wavelet_Transform_based_Image _Stegnography/cat.jpg"
messages = {
    44: "The quick brown fox jumps over the lazy dog.",
    123: "Steganography is the practice of concealing a file, message, image, or video within another file, message, image, or video.",
    149: "In cryptography, steganography is often used to hide secret messages or information within an innocuous cover medium, such as an image or audio file.",
    164: "The art of steganography dates back to ancient times when people would hide secret messages by tattooing them on messengers' bodies or encoding them in wax tablets.",
    209: "Today, steganography finds applications in digital watermarking, copyright protection, covert communication, and data hiding in multimedia files, among other areas of computer science and information security."
}

for key, message in messages.items():
    concatenated_message = message + message + message
    psnr_val = embed_message_in_image(cover_image_path, concatenated_message)
    print(f"Message {key} concatenated: PSNR = {psnr_val}")
