from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import numpy as np
from PIL import Image
import pywt

def encrypt_message(message, key):
    cipher = AES.new(key, AES.MODE_ECB)
    encrypted_message = cipher.encrypt(pad(message.encode(), AES.block_size))
    return encrypted_message

def embed_message_in_image(cover_image_path, message, key):
    cover_image = Image.open(cover_image_path).convert('L')  # Convert to grayscale
    width, height = cover_image.size

    encrypted_message = encrypt_message(message, key)

    stego_image = np.array(cover_image)

    for i in range(0, len(encrypted_message), 16):
        block = encrypted_message[i:i+16]

        # Check if the size of the encrypted block is greater than the available space in LSB
        if i * 8 + len(block) > width * height * 3:
            raise ValueError("Message is too large for the cover image")

        # Haar wavelet transform on the cover image
        coeffs = pywt.dwt2(stego_image, 'haar')
        LL, (LH, HL, HH) = coeffs

        # Embed encrypted block in the LL (approximation) subband
        reshaped_block = np.unpackbits(np.frombuffer(block, dtype=np.uint8))
        reshaped_block = reshaped_block[:len(LL.flat)]

        # Convert the LL coefficients to uint8 and round the values
        LL = np.round(LL).astype(np.uint8)

        LL_flat = LL.flat
        for j in range(len(reshaped_block)):
            if reshaped_block[j] == 1:
                LL_flat[j] |= 1
            else:
                LL_flat[j] &= 254

        coeffs = LL, (LH, HL, HH)
        stego_image = pywt.idwt2(coeffs, 'haar')

    stego_image = np.round(stego_image).astype(np.uint8)
    stego_image = Image.fromarray(stego_image)
    stego_image.save("stego_pink_2.jpeg")

# Example usage
cover_image_path = "C:/Users/hp/Desktop/mini_sem6/Haar_Wavelet_Transform_based_Image _Stegnography/pink.jpeg"
message = "my_saree_is_pink"
key = b'miniProject_sem6'
embed_message_in_image(cover_image_path, message, key)
